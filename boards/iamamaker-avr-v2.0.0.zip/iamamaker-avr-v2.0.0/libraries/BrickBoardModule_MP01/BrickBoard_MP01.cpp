/*
 *  BrickBoard_MP01.cpp
 *  - BrickBoard Multi-Port Module(MP01) Library
 *
 *  (c) 2015-2016 IAMAMAKER
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU License...
 *  See the GNU License for more details.
 */

#include "BrickBoard_MP01.h"


/*****************
 *  MP01
 *****************/
BrickBoard_MP01::BrickBoard_MP01(): BrickBoard_Ports()
{   /* Nothing */   }

BrickBoard_MP01::BrickBoard_MP01(uint8_t portName): BrickBoard_Ports(portName, MODE0)
{   /* Nothing */   }

BrickBoard_MP01::BrickBoard_MP01(uint8_t portName, uint8_t cppMode): BrickBoard_Ports(portName, cppMode)
{   /* Nothing */   }