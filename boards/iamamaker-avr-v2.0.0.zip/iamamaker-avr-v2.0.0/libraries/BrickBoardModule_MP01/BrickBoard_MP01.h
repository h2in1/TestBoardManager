#ifndef __BRICKBOARD_MP01_H__
#define __BRICKBOARD_MP01_H__

#include <BrickBoard.h>


/* Class of BrickBoard MP01 */
class BrickBoard_MP01: public BrickBoard_Ports
{
public:
    BrickBoard_MP01();
    BrickBoard_MP01(uint8_t portName);
    BrickBoard_MP01(uint8_t portName, uint8_t cppMode);
};

#endif /* __BRICKBOARD_MP01_H__ */
